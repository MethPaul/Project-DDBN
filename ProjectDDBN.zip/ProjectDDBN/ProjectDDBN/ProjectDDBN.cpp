﻿#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <limits>
#include <algorithm>
#define _USE_MATH_DEFINES
#include <cmath>

// Struct pentru reprezentarea unui oraș
struct City {
    std::string name;
    double latitude;
    double longitude;
};

// Funcție pentru calculul distanței dintre două orașe pe baza coordonatelor lor
double calculateDistance(const City& city1, const City& city2) {
    double lat1 = city1.latitude;
    double lon1 = city1.longitude;
    double lat2 = city2.latitude;
    double lon2 = city2.longitude;
    double degToRad = std::acos(-1) / 180.0;


    // Formula haversine pentru calculul distanței pe sferă
    double dlon = (lon2 - lon1) * degToRad;
    double dlat = (lat2 - lat1) * degToRad;
    double a = pow(sin(dlat / 2), 2) + cos(lat1 * degToRad) * cos(lat2 * degToRad) * pow(sin(dlon / 2), 2);
    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    double distance = 6371 * c; // Raza Pământului în km

    return distance;
}

// Funcție pentru generarea permutărilor posibile ale unui șir de orașe
void generatePermutations(std::vector<int>& route, const std::vector<std::vector<double>>& distances, double& shortestDistance, std::vector<int>& shortestRoute, size_t start = 1) {
    if (start == route.size() - 1) {
        double totalDistance = 0;
        for (size_t i = 0; i < route.size() - 1; ++i) {
            totalDistance += distances[route[i]][route[i + 1]];
        }
        if (totalDistance < shortestDistance) {
            shortestDistance = totalDistance;
            shortestRoute = route;
        }
        return;
    }
    for (size_t i = start; i < route.size(); ++i) {
        std::swap(route[start], route[i]);
        generatePermutations(route, distances, shortestDistance, shortestRoute, start + 1);
        std::swap(route[start], route[i]);
    }
}

int main() {
    // Citirea orașelor și coordonatelor lor din fișier
    std::ifstream inputFile("coordonate.txt");
    if (!inputFile) {
        std::cerr << "Nu am putut deschide fisierul de intrare.\n";
        return 1;
    }
    std::string line;
    std::vector<City> cities;
    while (std::getline(inputFile, line)) {
        std::stringstream ss(line);
        City city;
        ss >> city.name >> city.latitude >> city.longitude;
        cities.push_back(city);
    }
    inputFile.close();

    // Calcularea distanțelor între toate perechile posibile de orașe
    std::vector<std::vector<double>> distances(cities.size(), std::vector<double>(cities.size()));
    for (size_t i = 0; i < cities.size(); ++i) {
        for (size_t j = 0; j < cities.size(); ++j) {
            distances[i][j] = calculateDistance(cities[i], cities[j]);
        }
    }

    // Crearea unei rute inițiale cu toate orașele
    std::vector<int> initialRoute(cities.size());
    for (size_t i = 0; i < initialRoute.size(); ++i) {
        initialRoute[i] = i;
    }

    // Căutarea rutei cea mai scurte folosind backtracking
    double shortestDistance = std::numeric_limits<double>::infinity();
    std::vector<int> shortestRoute;
    generatePermutations(initialRoute, distances, shortestDistance, shortestRoute);

    // Afișarea rutei celei mai scurte și a distanței ei totale
    std::cout << "Ruta cea mai scurta: ";
    for (size_t i = 0; i < shortestRoute.size(); ++i) {
        std::cout << cities[shortestRoute[i]].name << " -> ";
    }
    std::cout << cities[shortestRoute[0]].name << '\n'; // Întoarcerea la orașul de start
    std::cout << "Distanta totala: " << shortestDistance << " km\n";

    return 0;
}